To view the result
	(1) I use vscode live server extension (Note: to use live server, the folder must be opened in the explorer)
	(2) use python -m http.server 8000 and then go to browser localhost:8000